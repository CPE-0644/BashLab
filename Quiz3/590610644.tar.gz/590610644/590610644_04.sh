#!/bin/bash

if (($# == 0));
    then
    echo "Where is your inputfile?"
else 
    declare -a prices amounts names
    i=0
    for row in `sort -k1 $1 | cut -d ',' -f1 | tr a-z A-Z`; do
        names[$i]=$row
        ((i++))
    done

    i=0
    for row in `sort -k1 $1 | cut -d ',' -f2`; do
        prices[$i]=$row
        ((i++))
    done

    i=0
    for row in `sort -k1 $1 | cut -d ',' -f3`; do
        amounts[$i]=$row
        ((i++))
    done

    all_amounts=0
    for am in `sort -k1 $1 | cut -d ',' -f3`;
    do
        ((all_amounts+=$am))
    done


    i=0
    j=1
    all_prices=0
    for row in `more $1 `;
    do
        echo "$j) ${names[$i]}(${amounts[$i]}) : $((${prices[$i]}*${amounts[$i]}))"
        ((all_prices+=$((${prices[$i]}*${amounts[$i]}))))
        ((i++))
        ((j++))
    done

    echo "   Total($all_amounts) : $all_prices"
fi